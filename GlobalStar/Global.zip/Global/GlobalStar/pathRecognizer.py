import os


def obtainPath():
    #print('getcwd:      ', os.getcwd())
    return os.getcwd()
    #print('__file__:    ', __file__)