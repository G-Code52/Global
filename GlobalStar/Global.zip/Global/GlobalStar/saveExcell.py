import os
import shutil as sh
from pathRecognizer import obtainPath
import xlsxwriter as writer



totalFiles = 0

def createFile(pathfiles):        #path: path where .xlsx saves
    for files in os.walk(pathfiles):
        print(files)
        totalFiles = len(files[2])
    print(totalFiles)
    totalFiles += 1

    sh.copy("Plantilla.xlsx", "FinalResults\Final"+str(totalFiles)+".xlsx")




def requestData():

    PATH = obtainPath()
    workbook = writer.Workbook('Plantilla.xlsx')
    worksheet = workbook.add_worksheet()
    Plantilla(worksheet)


    workbook.close()
    print("llegue")


def Plantilla(worksheet):

    worksheet.write(0, 1, "Start")
    worksheet.write(0, 2, "Power amplifier temperature [tenth of °C]")
    worksheet.write(0, 3, "Last RSSI")
    worksheet.write(0, 4, "GND RSSI")
    worksheet.write(0, 5, "Power convertes voltage [mV] [PV1]")
    worksheet.write(0, 6, "Power convertes voltage [mV] [PV2]")
    worksheet.write(0, 7, "Power convertes voltage [mV] [PV3]")
    worksheet.write(0, 8, "Battery voltage [mV]")
    worksheet.write(0, 9, "Current in [mA] [1]")
    worksheet.write(0, 10, "Current in [mA] [2]")
    worksheet.write(0, 11, "Current in [mA] [3]")
    worksheet.write(0, 12, "Boost converters current [mA]")
    worksheet.write(0, 13, "Boost converters current [mA]")
    worksheet.write(0, 14, "Output current [mA] [1]")
    worksheet.write(0, 15, "Output current [mA] [2]")
    worksheet.write(0, 16, "Output current [mA] [3]")
    worksheet.write(0, 17, "Output current [mA] [4]")
    worksheet.write(0, 18, "Output channels status [0 or 1] [1]")
    worksheet.write(0, 19, "Output channels status [0 or 1] [2]")
    worksheet.write(0, 20, "Output channels status [0 or 1] [3]")
    worksheet.write(0, 21, "Output channels status [0 or 1] [4]")
    worksheet.write(0, 22, "I2C wdt time left [s]")
    worksheet.write(0, 23, "GND wdt time left [s]")
    worksheet.write(0, 24, "WDT GND reboot number")
    worksheet.write(0, 25, "Batteries temperature sensor")
    worksheet.write(0, 26, "Sensor A value")
    worksheet.write(0, 27, "PWM current")
    worksheet.write(0, 28, "Last OBC reboot cause")
    worksheet.write(0, 29, "Magnetometer - X axis")
    worksheet.write(0, 30, "Magnetometer - Y axis")
    worksheet.write(0, 31, "Magnetometer - Z axis")
    worksheet.write(0, 32, "Gyro - X axis")
    worksheet.write(0, 33, "Gyro - Y axis")
    worksheet.write(0, 34, "Gyro - Z axis")
    worksheet.write(0, 35, "Coarse Sun Sensors Value +Y")
    worksheet.write(0, 36, "Coarse Sun Sensors Value +X")
    worksheet.write(0, 37, "Coarse Sun Sensors Value -X")
    worksheet.write(0, 38, "Coarse Sun Sensors Value -Y")
    worksheet.write(0, 39, "Coarse Sun Sensors Value -Z")
    worksheet.write(0, 40, "Solar Panel's Temperature +Y")
    worksheet.write(0, 41, "Solar Panel's Temperature +X")
    worksheet.write(0, 42, "Solar Panel's Temperature -X")
    worksheet.write(0, 43, "Solar Panel's Temperature -Y")
    worksheet.write(0, 44, "Solar Panel's Temperature -Z")
    worksheet.write(0, 45, "Bdot Status")
    worksheet.write(0, 46, "Bdot Value from low-pass filter slow")
    worksheet.write(0, 47, "Bdot Value from low-pass filter slow2")
    worksheet.write(0, 48, "Value of detumbled state")
    worksheet.write(0, 49, "RF Channel")
    worksheet.write(0, 50, "# Bursts")
    worksheet.write(0, 51, "Minimum Burst Interval")
    worksheet.write(0, 52, "Maximum Burst Interval")
    worksheet.write(0, 53, "Hardware Status")
    worksheet.write(0, 54, "Number of Seconds since las transmission")
    worksheet.write(0, 55, "Number of seconds until next transmission")
    worksheet.write(0, 56, "Packet size of last or current message")
    worksheet.write(0, 57, "Currently waiting on or sending burst number")
    worksheet.write(0, 58, "Number of seconds until burst transmission number 2")
    worksheet.write(0, 59, "Number of seconds until burst transmission number 3")
    worksheet.write(0, 60, "Total messages transmitted in current mode")
    worksheet.write(0, 61, "Total packet transmission count since hard power on")
    worksheet.write(0, 62, "Antenna Temperature")
    worksheet.write(0, 63, "Temperature of the SPI Sensor")
    worksheet.write(0, 64, "Unix Time")
    worksheet.write(0, 65, "END")





